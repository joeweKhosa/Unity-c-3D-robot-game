﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class coinsManager : MonoBehaviour
{
    public int coinValue = 1;

    void OnTrigger(Collider other)
    {
        if (other.tag == "Player")
        {
            Debug.Log("Player picked up a coin");

            managerS.instance.UpdateCoinCount(coinValue);

            Destroy(this.gameObject);
        }
    }

}