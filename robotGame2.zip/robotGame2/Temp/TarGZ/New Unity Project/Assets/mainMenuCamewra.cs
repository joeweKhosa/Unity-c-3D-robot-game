﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mainMenuCamewra : MonoBehaviour
{
    public GameObject Panel;
    private mainMenuCamewra mainMenuCamera;
    public void StartGame()
    {
        SceneLoader.instance.LoadLevel("robotGame");
    }

    void Awake()
    {
        mainMenuCamera = Camera.main.GetComponent<mainMenuCamewra>();
    }
}
