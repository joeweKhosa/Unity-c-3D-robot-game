﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class managerS : MonoBehaviour
{
    public Text coin = null;
    public Camera camera = null;
    public GameObject guiGameOver = null;

    private int currentCoins = 0;
    private bool canPlay = false;

    private static managerS s_Instance;
    public static managerS instance
    {
        get
        {
            if (s_Instance == null)
            {
                s_Instance = FindObjectOfType(typeof(managerS)) as managerS;
            }
            return s_Instance;
        }
    }

    void Start()
    {
        // TODO: generate new level piece here
    }

    public void UpdateCoinCount(int value)
    {
        Debug.Log("Player picked up another coin for" + value);

        currentCoins += value;

        coin.text = currentCoins.ToString();
    }

    public bool CanPlay()
    {
        return canPlay;
    }
    public void StartPlay()
    {
        canPlay = true;
    }

    public void GamePver()
    {

        GuiGameOver();
    }

    void GuiGameOver()
    {
        Debug.Log("Game Over");

        guiGameOver.SetActive(true);
    }

    public void PlayAgain()
    {
        Scene scene = SceneManager.GetActiveScene();

        SceneManager.LoadScene(scene.name);
    }

    public void Quit()
    {
        Application.Quit();
    }
}
