﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class playersHealth : MonoBehaviour
{
    public float health = 100f;
    private bool isShielded;
    private Animator anim;
    private Image Green_bar;

    void Awake()
    {
        anim = GetComponent<Animator>();

        Green_bar = GameObject.Find("Green Bar").GetComponent<Image>();
    }

    public bool Shielded
    {
        get { return isShielded;}
        set { isShielded = value;}
    }

    public void TakeDamage(float amount)
    {
        if (!isShielded)
        {
            health -= amount;
            Green_bar.fillAmount = health / 100f;

            if (health <= 0f)
            {
                anim.SetBool("Death", true);

                if (!anim.IsInTransition(0) && anim.GetCurrentAnimatorStateInfo(0).IsName("Death") && anim.GetCurrentAnimatorStateInfo(0).normalizedTime >= 0.95)
                {
                }
            }
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
